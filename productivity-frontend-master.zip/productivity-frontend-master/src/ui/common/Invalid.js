'use strict';

import React from 'react';

const Invalid = (props) => {

	return (
		<div>
			<h1>Invalid</h1>
		</div>
	)

}

export default Invalid;
