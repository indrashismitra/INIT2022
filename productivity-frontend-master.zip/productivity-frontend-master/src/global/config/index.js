'use strict';

export default {

	api: {
		endpoint: 'http://localhost:1200/graphql',
	},

};
