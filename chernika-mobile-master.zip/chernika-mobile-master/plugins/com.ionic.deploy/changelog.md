Changelog
=========

## 0.2.3

* Adding deploy info. Fixes #11
* Fix for ios deploys not sticking around after force quitting. Fixes #21


## 0.2.2

* Firing error callback in the event the deploy check is unable to receive a valid response. Fixes #14
* Removed StandardCharset dependency to support older Android platforms. Fixes #19
