#!/usr/bin/env node

require('./disable-bitcode.js')();
