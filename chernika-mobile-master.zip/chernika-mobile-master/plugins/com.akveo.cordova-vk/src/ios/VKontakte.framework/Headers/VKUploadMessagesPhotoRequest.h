//
//  VKUploadMessagesPhotoRequest.h
//  sdk
//
//  Created by Roman Truba on 05.08.14.
//  Copyright (c) 2014 VK. All rights reserved.
//

#import "VKUploadPhotoBase.h"

@interface VKUploadMessagesPhotoRequest : VKUploadPhotoBase

@end
