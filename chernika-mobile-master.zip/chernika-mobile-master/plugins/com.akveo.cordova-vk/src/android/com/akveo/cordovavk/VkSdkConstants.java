package com.akveo.cordovavk;

/**
 * @author v.lugovsky
 */
public interface VkSdkConstants {

    final String LOG_TAG = "vkSdk";
    final String S_TOKEN_KEY = "VK_ACCESS_TOKEN";
}
