//
//  OwbClientTests.h
//  OwbClientTests
//
//  Created by  tsgsz on 4/7/13.
//  Copyright (c) 2013 tsgsz. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface OwbClientTests : SenTestCase

@end
