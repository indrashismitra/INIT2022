//
//  pref.h
//  OwbClient
//
//  Created by  tsgsz on 4/7/13.
//  Copyright (c) 2013 tsgsz. All rights reserved.
//

#ifndef OwbClient_pref_h
#define OwbClient_pref_h

#define ScreenHeight    320
#define ScreenWidth     640

#define unknown 0

#endif
